  <?php  
                    if (check_if_added_to_cart($id)) {  
                    echo '<a href="p.php" class="btn btn-block btn-success" ></a>';
                    } 
                ?> 