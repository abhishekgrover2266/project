<?php
function img($n){
    return $n;
}?>