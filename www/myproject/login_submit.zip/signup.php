<?php
include 'common.php';
if (isset($_SESSION['Email'])) {
header('location: index.php');
}
?>

<html>
    <head>
        <title>SIGNUP</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="store.css">
        <style>
body{
    background: url("img/d7.jpg") no-repeat center;
    background-size:  cover;
    margin-top: 0px;
    width: 100%;
    height: 100%
}
</style>
   
       </head>
    <body>
        <div class="container">
            <nav class="navbar navbar-default" style="margin-bottom: 0px;">
            <div class="container">
                <div>
                    <ul class="nav navbar-nav">
                        <li><a href="index.html">HOME</a></li>
                        <li><a href="login.html">LOGIN</a></li>
                        <li><a href="signup.html">SIGNUP</a></li>
                        <li><a href="products.html">PRODUCTS</a></li>
                        <li><a href="cart.html" style="padding-left: 600px; font-family: sans-serif;font-style:  italic; font-size: 18px;"><span class="glyphicon glyphicon-shopping-cart"></span>Cart</a></li>
                        </ul>
                </div>
            </div>
        </nav>
            <div class="container-fluid">
         <div class="row">
                <div class="col-xs-4 col-xs-offset-4">
                    <center> <h2 style="margin-top: 100px;color: white">SIGN UP</h2></center>
                     <form method="post" action="signup_script.php">
                        <div class="form-group">
                            <b style="color: white">Name:</b>
                            <input type="text" name="Name" placeholder="name" class="form-control">
                        </div>
                        <div class="form-group">
                            <b style="color: white">Email:</b>
                                <input type="text" name="Email" placeholder="email" class="form-control">
                        </div>
                        <div></div>
                                <div class="form-group">
                                    <b style="color: white">Password:</b>
                                <input type="password" name="Password" placeholder="password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <b style="color: white">Contact</b>
                                <input type="text" name="Contact" placeholder="Contact" class="form-control">
                            
                                </div>
                        <div class="form-group">
                            <b style="color: white">Adress</b>
                            <input type="text" name="Adress" placeholder="Adress" class="form-control">
                        </div><br>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                         
   
                    </form>
                </div>
            </div>
            
        </div>
            <footer style="font-size: 19px;font-style:  initial;color: black;padding-top: 90px;padding-left: 50px;">
                <p style="background: white;font-family: cursive">copyright@krishnastore | CONTACT:9034628466 | EMAIL:as677694@gmail.com  |  BEST DEALS HERE.</p>
                    </footer>
    </body>
</html>
