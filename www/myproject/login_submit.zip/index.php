<?php
include 'common.php';
if (isset($_SESSION['email'])) {
header('location: index.php');
}

?>
<html>
    <head>
        <title>KRISHNA'S STORE</title>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="store.css">
     </head>
    <body>
       <?php
       include 'header.php';
       include 'login.php';
       ?><div class="banner_image">
            <div class="container">
                <center>
                <div class="banner_content">
                      <h1 style="font-family: cursive;font-style: initial;font-size: 47px;border-bottom: solid 2px black;color: gray ;padding-bottom: 25px;font-weight: bold;letter-spacing: 8px">KRISHNA HOME<br/>
                        ACCESORIES</h1>
                    <p style="padding-top: 15px;font-size: 30px;color:   tomato;font-family: monospace">MAKE HOME BEAUTIFUL</p>
                    
                </div></center>
</div>
            </div>
        <div class="container" style="overflow:  visible">
                        <center><h4 style="font-family:  cursive;font-size: 32px;color:  darkred " >PRODUCTS</center>
                                    <div class="row text-center">
                <div class="col-md-6 col-sm-6">
                    <div class="thumbnail">
                        <img src="img/p1.jpg" alt="cannon" class="img-responsive">
                        <div class="caption">
                            <h3 style="font-family: cursive;letter-spacing: 4px">PILLOW</h3>
                            Discount 40% OFF
                        <a href="products.php" style="color: white"><button class="btn btn-primary btn-block">buy now</button>
                    </div>
                </div>
            </div>
                    
                    
                <div class="col-md-6 col-sm-6">
                    <div class="thumbnail">
                        <img src="img/p2.jpg" alt="cannon" class="img-responsive" style="height: 395px">
                        <div class="caption">
                            <h3  style="font-family: cursive;letter-spacing: 4px">BED-SHEETS</h3>
                            <a href="products.php" style="color: white"><button class="btn btn-primary btn-block">buy now</button></a>
                    </div>
                </div>
            </div>
                 
                      
                
                    </div>
                    </div>
                    <div id="a">
                        <center><h3>ABOUT</h3></center>
                        <p style="font-family: cursive; font-size: 16px;">Expertly tailored from the highest quality materials, our luxury sheets are supple and smooth. Start fresh with bed basics or replace a well-loved set with our flat sheets, fitted sheets, and pillowcases—they're sold separately so you can buy a complete bedding set or mix and match to create a coordinated look of your own.<br/>

Sourced from diverse artisans and manufacturers around the world, our fabrics boast unique characteristics while maintaining the premium-grade quality for which we're known. Our line of bed sheets comes in a palette of sophisticated colors and prints, in fabrics including luxurious sateen, crisp percale, and organic cotton.<br/>

Our organic bedding is sustainably sourced and crafted using environmentally and socially responsible methods. It's healthy for you and the environment. Warm weather calls for the comfort of breathable linen or TENCEL™ Lyocell, while winter's chill is the perfect excuse to snuggle up in warm flannel sheets. Or, keep the prettiness practical with wrinkle-free bed sheets that emerge straight from the dryer just as soft, smooth, and pristine as they were the day you bought them.

We have the sizes you're looking for: shop Twin, Twin XL, Full, Queen, and King sheets. For mattresses more than 16 inches deep, our deep pocket sheets allow full coverage for comfort—without the slipping and bunching that comes with sheets that are too small.<br/>

Whimsical prints featuring lovable characters delight kids of all ages. Send your grown kids off to college with trendy Twin XL sheets in a wide array of solids and prints. Brighten a guest bedroom with sheets in a variety of colors and prints, or personalize your master bedroom with monogrammable sheet sets.<br/>

We introduce new sheet patterns every season, so refresh your bed with timely designs as the seasons change—from gorgeous florals and nature-inspired prints to geometric patterns and festive motifs.<br/>

Our collection will match your personal style and answer every comfort need. Choosing sheets that are right for you and your lifestyle is essential to a great night's sleep. Consult our Sheet Guide to learn everything you need to know about choosing bed sheets, including what thread count is best, what size to buy, and how to properly care for your bedding.</p>
                    </div>
                    <div class="i-b"></div>
                    </div>
                   
                        
                    </body>
</html>