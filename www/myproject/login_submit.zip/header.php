 <nav class="navbar navbar-default">
            <div class="container">
                <div>
                    <ul class="nav navbar-nav">
                        <li><a href="index.php"><u>HOME</u></a></li>
                        <li style="font-family: cursive;padding-left: 250px;font-weight: bold;letter-spacing: 4px;padding-top: 15px"><u>KRISHNA HOME ACCESSORIES</u></li>
                        <li style="font-family: cursive;padding-left: 150px;"><a href="#" data-toggle="modal" data-target="#loginmodal"><u>Login</u></a></li>
                        <li style="font-family: cursive;padding-left: 20px"><a href="signup.php"><u>SIGNUP</u></a></li>
                        
                        
                                    </ul>
                </div>
            </div>
        </nav>
       