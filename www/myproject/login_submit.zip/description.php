<?php
include 'common.php';?>
?> 
<html>
    <head>
        <title>cart</title>
                   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="store.css">
        <style>        h1{background: white;
        }</style>
  </head>
    <body>
          <div class="container">
        <nav class="navbar navbar-default">
            
                <div>
                    <ul class="nav navbar-nav" style="letter-spacing: 4px;padding-left: 30px">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="products.php">Products</a></li>
                        <li style="font-family: cursive;padding-left: 100px;font-weight: bold;letter-spacing: 4px;padding-top: 15px">KRISHNA HOME ACCESSORIES</li>
                        
                        <li><a href="about.html"style="padding-top: 15px;padding-left: 300px; font-family: sans-serif;font-style:  italic; font-size: 18px;"><span class="glyphicon glyphicon-user"></span></a></li>
                        <li><a href="settings.php">SETTING</a></li>
                    </ul>
                </div></nav> 
   
   <?php     $user_id=$_SESSION['id'];
        $query="SELECT id,Name,Price FROM items";
        $qr=mysqli_query($con,$query) or die(mysqli_error($con));
        $n=mysqli_num_rows($qr);
        $sum=0;
        $i=1;
        $arr= mysqli_fetch_array($qr);
             
while($n>0){
         $id=$arr['id'];
$imgUrl = "website/cushion/$id.jpg";?>
<img src="<?= $imgUrl; ?>" width="200px" height="150"/><?php
          $n--;
                  
}?>
          </div>
    </body>
</html>