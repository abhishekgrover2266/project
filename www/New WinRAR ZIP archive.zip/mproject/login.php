<?php
include 'includes/common.php';
if (isset($_SESSION['email'])) {
header('location: products.php');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Lifestyle Store-Login</title>
	<link rel="stylesheet" href="style.css" >
  </head>
  <body>
        <?php
        include 'includes/header.php';
        ?>
	<div class="row">
	<div class="col-xs-4 col-xs-offset-4">
	<div class="panel panel-primary" style="margin-top:100px;">
	<div class="panel-heading">
	<h2>LOGIN</h2>
	</div>
	<div class="panel-body">
	<p class="text-warning">Login to make a purchase</p>
        <form method="post" action="login_submit.php">
	<div class="form-group">
	<input type="text" name="email" placeholder="Email" class="form-control">
	</div>
	<div class="form-group">
	<input type="password" name="password" placeholder="Password" class="form-control">
	</div>
	<div class="form-group">
        <input type="submit" class="btn btn_primary" value="Login">
	</div>
	</div>
	<div class="panel-footer" >
	Don't have an account?<a href="signup.php">Register</a>
	</div>
	</div>
	</div>
	</div>
        <?php
        include 'includes/footer.php';
        ?>
  </body>
</html>
	