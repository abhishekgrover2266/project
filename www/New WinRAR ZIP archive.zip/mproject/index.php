<?php
include 'includes/common.php';
if (isset($_SESSION['email'])) {
header('location: products.php');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>Lifestyle Store</title>
	<link rel="stylesheet" href="style.css" >
  </head>
  <body>
        <?php
        include 'includes/header.php';
        ?>
	<div class="banner_image">
	<div class="container">
	<center>
	<div class="banner_content">
	<h1>We sell lifestyle.</h1>
	<p>Flat 40% OFF on premium brands</p>
	<a href="login.php" class="btn btn-danger btn-lg active">Shop Now</a>
	</div></center>
	</div>
	</div>
        <?php
        include 'includes/footer.php';
        ?>
  </body>
</html>